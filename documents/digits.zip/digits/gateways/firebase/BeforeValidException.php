<?php
namespace Firebase\Dig_Firebase;

use UnexpectedValueException;

class BeforeValidException extends UnexpectedValueException
{

}
