<?php
include plugin_dir_path(__DIR__) .'melipayamak/MelipayamakApi.php';
include plugin_dir_path(__DIR__) .'melipayamak/BaseSms.php';
include plugin_dir_path(__DIR__) .'melipayamak/Branch.php';
include plugin_dir_path(__DIR__) .'melipayamak/Contacts.php';
include plugin_dir_path(__DIR__) .'melipayamak/SmsRest.php';
include plugin_dir_path(__DIR__) .'melipayamak/SmsSoap.php';
include plugin_dir_path(__DIR__) .'melipayamak/Ticket.php';
include plugin_dir_path(__DIR__) .'melipayamak/Users.php';
