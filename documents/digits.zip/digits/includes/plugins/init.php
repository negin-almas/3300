<?php


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once( 'um.php' );
require_once( 'bp.php' );
require_once( 'ihu.php' );
