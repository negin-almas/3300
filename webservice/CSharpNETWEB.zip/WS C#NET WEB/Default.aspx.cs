﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebServiceTest.ir._3300.sms;
namespace WebServiceTest
{
    public partial class Default : System.Web.UI.Page
    {
        string sms_username = "user"; //Web Service Username
        string sms_password = "pass"; //Web Service Password

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BTN_receive_Click(object sender, EventArgs e)
        {
            string[] text, mobile, mid;
            DateTime[] date;
            AlmasSms ws = new AlmasSms();
            long result = ws.GetReceivedSms3(sms_username, sms_password, out text, out mobile, out mid, out date);
            if (result < 0)
            {
                int i = 0;
                litResult.Text = "no unread messages";
                foreach (string item in text)
                {
                    if (i == 0) litResult.Text = "";
                    litResult.Text = litResult.Text + "Mobile:" + mobile[i];
                    litResult.Text = litResult.Text + "  Date:" + date[i].ToString() + "<br/>";
                    litResult.Text = litResult.Text + item + "<br/>";
                    litResult.Text = litResult.Text + "----------------------------------------------------------" + "<br/>";
                    i++;
                }
            }
            else
            {
                litResult.Text = messages.METHOD_errors(result);
            }
        }

        protected void BTN_send_Click(object sender, EventArgs e)
        {
            long[] mids;
            AlmasSms ws = new AlmasSms();
            //WebProxy myproxy = new WebProxy("localhost", 800);
            //myproxy.Credentials = new NetworkCredential("proxy username", "proxy password");
            //ws.Proxy = myproxy;

            long result = ws.SendSms(sms_username, sms_password, new string[] { TXT_message.Text }, new string[] { TXT_mobile.Text }, out mids);
            if (result < 0)
            {
                litResult.Text = "";
                foreach (long item in mids)
                {
                    if (item > 1000)
                    {
                        litResult.Text = litResult.Text + "Message Id:" + item + "<br/>";
                        TXT_status.Text = item.ToString();
                    }
                    else
                        litResult.Text = litResult.Text + "Error:" + messages.MAGFA_errors(item) + "<br/>";
                }
            }
            else
            {
                litResult.Text = messages.METHOD_errors(result);
            }
        }

        protected void BTN_status_Click(object sender, EventArgs e)
        {
            int[] status;
            AlmasSms ws = new AlmasSms();
            long mid = 0;
            Int64.TryParse(TXT_status.Text, out mid);
            if (mid > 1000)
            {
                long result = ws.GetRealMessageStatuses(sms_username, sms_password, new long[] { mid }, out status);
                if (result < 0)
                {
                    litResult.Text = "";
                    foreach (int item in status)
                    {
                        litResult.Text = litResult.Text + messages.message_status(item) + "<br/>";

                    }
                }
                else
                {
                    litResult.Text = messages.METHOD_errors(result);
                }
            }
        }

        protected void BTN_credit_Click(object sender, EventArgs e)
        {

            AlmasSms ws = new AlmasSms();
            long credit;

            long result = ws.GetCredit(sms_username, sms_password, out credit);
            if (result < 0)
            {

                litResult.Text = credit.ToString() + "RIALS<br/>";
            }
            else
            {
                litResult.Text = messages.METHOD_errors(result);
            }

        }

    }
}