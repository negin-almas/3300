<?php
//update:1396-4-7
require_once('nusoap/nusoap.php');
require_once('messages.php');
//WEB SERVICE PARAMETERS
$webservice_url = 'http://sms.3300.ir/almassms.asmx?wsdl';
//درصورتی که شماره‌ی خط پیامک شما با 30003200 شروع می شود به جای خط بالا، خط زیر را از حالت کامنت خارج کنید.
//$webservice_url = 'http://sms.3200.ir/almassms.asmx?wsdl';
$sms_username = 'USERNAME'; //Web Service Username
$sms_password = 'PASSWORD'; //Web Service Password
for ($i = 1; $i <= 1; $i++) {
    $mysms[$i] = 'پیام' . $i;
    $mymobile[$i] = 'MOBILE_NUMNER';
}
//WEB SERVICE INIT------------------------------------------------------------
$client = new nusoap_client($webservice_url, 'wsdl', '', '', '', '');
$client->soap_defencoding = 'UTF-8';
$client->decode_utf8 = false;
if ($client->fault) {
    trigger_error("SOAP Fault: (faultcode: {$client->faultcode}, faultstring: {$client->faulstring})", E_ERROR);
} else {
    // Check for errors
    $err = $client->getError();
    if ($err) {
        // Display the error
        echo '<h2>Error</h2><pre>' . $err . '</pre>';
    }
}
//WEB SERVICE INIT-------------------------------------------------------------
//SEND SMS---------------------------------------------------------------------
$sms_text = array('string' => $mysms); //SMS TEXT(s)
$sms_mobile = array('string' => $mymobile); //SMS Mobile(S) Number
$sms_uhd[] = ''; //Null UDH
$sms_encodings['int'] = 2; //UTF8  Encoding
$sms_mclass['int'] = 1; //Save Message In Phone Memory
$param = array(
    'pUsername' => $sms_username,
    'pPassword' => $sms_password,
    'messages' => $sms_text,
    'mobiles' => $sms_mobile,
    'Encodings' => $sms_encodings,
    'mclass' => $sms_mclass
);
$results = $client->call("SendSms2", $param);
if ($results['SendSms2Result'] < 0) {
    echo 'Method executed successfully without any errors' . '<br/>';
    //var_dump($results);
    foreach ($results['pMessageIds']['long'] as $pmId) {
        if ($pmId < 1000)
            echo ++$c . ') ERROR' . $pmId . '-' . $MAGFA_errors[$pmId]['title'] . '<br/>';
        else
            echo ++$c . ')' . 'Successfull(SMS ID : ' . $pmId . ')<br/>';
    }
} else {
    echo 'Method execution failed' . '<br/>';
    echo $METHOD_errors[$results['SendSms2Result']]['title'];
}
//SEND SMS---------------------------------------------------------------------
?>
