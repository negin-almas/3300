<?php
//update:1396-4-7
require_once('nusoap/nusoap.php');
include_once('messages.php');
//WEB SERVICE PARAMETERS
$sms_url='http://sms.3300.ir/almassms.asmx?wsdl';//Web Service URL
$sms_username = 'user'; //Web Service Username
$sms_password = 'pass'; //Web Service Password

$pmid[0] = 9628945674;
$pmid[1] = 9628941782;
//WEB SERVICE INIT------------------------------------------------------------
$client = new nusoap_client($sms_url, 'wsdl', '', '', '', '');
if ($client->fault) {
    trigger_error("SOAP Fault: (faultcode: {$client->faultcode}, faultstring: {$client->faulstring})", E_ERROR);
} else {
    // Check for errors
    $err = $client->getError();
    if ($err) {
        // Display the error
        echo '<h2>Error</h2><pre>' . $err . '</pre>';
    }
}
//WEB SERVICE INIT-------------------------------------------------------------
		$result = $client->call('GetRealMessageStatuses', array(
			'pUsername' => $sms_username,
			'pPassword' => $sms_password,
			'pMessageIds' => array('long' =>$pmid)// unique codes of SMS
		));
		//echo var_dump($result);
if ($result['GetRealMessageStatusesResult'] < 0)
	{
	echo 'Method executed successfully without any errors'.'<br/>';
	foreach($result ["pStatuses"]['int'] as $i)
		echo ++$c.')'.$message_status[$i]['title'].'<br/>';
	}
else
	{
	echo 'Method execution failed'.'<br/>';
	echo $METHOD_errors[$result['GetRealMessageStatusesResult']]['title'];
	}
	?>
