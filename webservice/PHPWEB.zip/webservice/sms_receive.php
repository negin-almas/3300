<?php
//update:1392-05-13
require_once('lib/nusoap.php');
include_once('messages.php');
//WEB SERVICE PARAMETERS
$sms_url='http://sms.3300.ir/almassms.asmx?wsdl';//Web Service URL
$sms_username = 'user'; //Web Service Username
$sms_password = 'pass'; //Web Service Password
//WEB SERVICE INIT------------------------------------------------------------
$client = new nusoap_client($sms_url, 'wsdl', '', '', '', '');
if ($client->fault) {
    trigger_error("SOAP Fault: (faultcode: {$result->faultcode}, faultstring: {$result->faulstring})", E_ERROR);
} else {
    // Check for errors
    $err = $client->getError();
    if ($err) {
        // Display the error
        echo '<h2>Error</h2><pre>' . $err . '</pre>';
    }
}
//WEB SERVICE INIT-------------------------------------------------------------
		$client->soap_defencoding = 'UTF-8';
		$client->decode_utf8 = false;
		$result = $client->call('GetReceivedSms3', array(
			'pUsername' => $sms_username,
			'pPassword' => $sms_password
		));
		//echo var_dump($result);
 if ($result['GetReceivedSms3Result'] < 0)  
	{
	echo 'Method executed successfully without any errors'.'<br/>';
	$c=count($result['pFroms']["string"]);
	//echo $c;
	if($result['pFroms']["string"]!=null && $c==1)
	{
	echo 'mobile:'.$result['pFroms']["string"].'  date:'.$result['pEnteredDate']["dateTime"]."<br/>";
	echo 'text  :'.$result['pMessages']["string"]."<br/>";
	}
	else if($c>1)
	for ($i=0;$i< $c;$i++) 
				{
				echo 'mobile:'.$result['pFroms']["string"][$i].'  date:'.$result['pEnteredDate']["dateTime"][$i]."<br/>";
				echo 'text  :'.$result['pMessages']["string"][$i]."<br/>";
				echo '----------------------------------------------------------'."<br/>";
				}
	else echo 'no unread messages';
	}
else
	{
	echo 'Method execution failed'.'<br/>';
	echo $METHOD_errors[$result['GetReceivedSms3Result']]['title'];
	}
	?>

