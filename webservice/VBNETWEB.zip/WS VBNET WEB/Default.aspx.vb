﻿Imports Web_VB.ir._3300.sms
Imports System.Net

Public Class _Default

    Inherits System.Web.UI.Page
    Dim sms_username = "user"
    Dim sms_password = "pass"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub


    Protected Sub BTN_receive_Click(sender As Object, e As EventArgs) Handles BTN_receive.Click
        Dim text As String(), mobile As String(), mid As String()
        Dim [date] As DateTime()
        Dim ws As New AlmasSms()
        Dim result As Long = ws.GetReceivedSms3(sms_username, sms_password, text, mobile, mid, [date])
        If result < 0 Then
            Dim i As Integer = 0
            litResult.Text = "no unread messages"
            For Each item As String In text
                If i = 0 Then
                    litResult.Text = ""
                End If
                litResult.Text = litResult.Text + "Mobile:" & mobile(i)
                litResult.Text = litResult.Text + "  Date:" & [date](i).ToString() & "<br/>"
                litResult.Text = litResult.Text + item & "<br/>"
                litResult.Text = litResult.Text + "----------------------------------------------------------" & "<br/>"
                i += 1
            Next
        Else
            litResult.Text = messages.METHOD_errors(result)
        End If
    End Sub

    Protected Sub BTN_status_Click(sender As Object, e As EventArgs) Handles BTN_status.Click
        Dim status As Integer()
        Dim ws As New AlmasSms()
        Dim mid As Long = 0
        Int64.TryParse(TXT_status.Text, mid)
        If mid > 1000 Then
            Dim result As Long = ws.GetRealMessageStatuses(sms_username, sms_password, New Long() {mid}, status)
            If result < 0 Then
                litResult.Text = ""
                For Each item As Integer In status
                    litResult.Text = litResult.Text + messages.message_status(item) + "<br/>"
                Next
            Else
                litResult.Text = messages.METHOD_errors(result)
            End If
        End If
    End Sub

    Protected Sub BTN_send_Click(sender As Object, e As EventArgs) Handles BTN_send.Click
        Dim mids As Long()
        Dim ws As New AlmasSms()
        'Dim myproxy As New WebProxy("localhost", 800)
        'myproxy.Credentials = New NetworkCredential("proxy username", "proxy password")
        'ws.Proxy = myproxy

        Dim result As Long = ws.SendSms(sms_username, sms_password, New String() {TXT_message.Text}, New String() {TXT_mobile.Text}, mids)
        If result < 0 Then
            litResult.Text = ""
            For Each item As Long In mids
                If item > 1000 Then
                    litResult.Text = litResult.Text + "Message Id:" & item & "<br/>"
                    TXT_status.Text = item.ToString()
                Else
                    litResult.Text = litResult.Text + "Error:" & messages.MAGFA_errors(item) & "<br/>"
                End If
            Next
        Else
            litResult.Text = messages.METHOD_errors(result)
        End If
    End Sub

    Protected Sub BTN_credit_Click(sender As Object, e As EventArgs) Handles BTN_credit.Click
        Dim ws As New AlmasSms()
        Dim credit As Long

        Dim result As Long = ws.GetCredit(sms_username, sms_password, credit)
        If result < 0 Then

            litResult.Text = credit.ToString() & "RIALS<br/>"
        Else
            litResult.Text = messages.METHOD_errors(result)
        End If
    End Sub
End Class