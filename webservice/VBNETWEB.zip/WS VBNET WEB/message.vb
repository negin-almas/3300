﻿Public Class messages
    Public Shared Function MAGFA_errors(code As Long) As [String]
        Select Case code
            Case -1
                Return "The target of report is not available(e.g. no message is associated with entered IDs)"
            Case 1
                Return "the Strings You presented as recipient numbers are not valid phone numbers, please check'em again"
            Case 2
                Return "the Strings You presented as sender numbers(3000-blah blah blahs) are not valid numbers, please check'em again"
            Case 3
                Return "are You sure You've entered the right encoding for this message? You can try other encodings to bypass this error code"
            Case 4
                Return "entered MessageClass is not valid. for a normal MClass, leave this entry empty"
            Case 6
                Return "entered UDH is invalid. in order to send a simple message, leave this entry empty"
            Case 12
                Return "you're trying to use a service from another account??? check your UN/Password/NumberRange again"
            Case 13
                Return "check the text of your message. it seems to be null."
            Case 14
                Return "Your credit's not enough to send this message. you might want to buy some credit.call "
            Case 15
                Return "something bad happened on server side, you might want to call MAGFA Support about this:"
            Case 16
                Return "Your account is not active right now, call -- to activate it"
            Case 17
                Return "looks like Your account's reached its expiration time, call -- for more information"
            Case 18
                Return "the combination of entered Username/Password/Domain is not valid. check'em again"
            Case 19
                Return "You're not entering the correct combination of Username/Password"
            Case 20
                Return "check the service type you're requesting. we don't get what service you want to use. your sender number might be wrong, too."
            Case 22
                Return "your current number range doesn't have the permission to use Webservices"
            Case 23
                Return "Sorry, Server's under heavy traffic pressure, try testing another time please"
            Case 24
                Return "entered message-id seems to be invalid, are you sure You entered the right thing?"
            Case 106
                Return "array of recipient numbers must have at least one member"
            Case 107
                Return "the maximum number of recipients per message is 90"
            Case 108
                Return "array of sender numbers must have at least one member"
            Case 103
                Return "This error happens when you have more than one " & "sender-number for message. when you have more than one sender number, for each sender-number you must " & "define a recipient number..."
            Case 101
                Return "when you have N > 1 texts to send, you have to define N recipient-numbers..."
            Case 104
                Return "this happens when you try to define UDHs for your messages. in this case you must define one recipient number for each udh"
            Case 102
                Return "this happens when you try to define MClasses for your messages. in this case you must define one recipient number for each MClass"
            Case 109
                Return "this happens when you try to define encodings for your messages. in this case you must define one recipient number for each Encoding"
            Case 110
                Return "this happens when you try to define checking-message-ids for your messages. in this case you must define one recipient number for each checking-message-id"
            Case Else
                Return ""
        End Select
    End Function
    '----------------------------------------------------------------------------
    Public Shared Function message_status(code As Integer) As [String]
        Select Case code
            Case 0
                Return "Unknown"
            Case 1
                Return "Mobile Delivered"
            Case 2
                Return "Mobile Failed"
            Case 8
                Return "SMS Center Delivered"
            Case 16
                Return "SMS Center Failed"
            Case Else
                Return ""
        End Select
    End Function
    '----------------------------------------------------------------------------
    Public Shared Function METHOD_errors(code As Long) As [String]
        Select Case code
            Case 0
                Return "Exception"
            Case 14
                Return "INVALID_USER_CREDIT"
            Case 18
                Return "INVALID_USERNAME_PASSWORD"
            Case 20
                Return "INVALID_SENDID"
            Case 100
                Return "INVALID_ARRAY_ENCODING_LENGTH"
            Case 101
                Return "INVALID_ARRAY_MESSAGE_LENGTH"
            Case 102
                Return "INVALID_ARRAY_MCLASS_LENGTH"
            Case 103
                Return "INVALID_ARRAY_MOBILES_LENGTH"
            Case 104
                Return "INVALID_ARRAY_UDH_LENGTH"
            Case 1000
                Return "INVALID_READY_FOR_SEND"
            Case Else
                Return ""
        End Select
    End Function

End Class
