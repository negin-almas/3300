<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.helper');

class action{

function SendSMS($msg){
	global $mainframe;
	$db =& JFactory::getDBO();
	$query = "SELECT * FROM #__sms_subscriptions WHERE status='subscribed'";
	$db->setQuery($query);
	$resObj = $db->loadObjectList();
	$res = $db->query();
	$rownum = $db->getNumRows();
	
	
	//quering the parameters
	//$params = new JRegistry('com_smsnewsletter');
    $params = JComponentHelper::getParams('com_smsnewsletter');
    $sms_number = $params->get('sms_number');
	$sms_url = $params->get('sms_api');
	$sms_user = $params->get('sms_user');
	$sms_password = $params->get('sms_password');
   
	//sending the messages to the subscribers
	$phones = "";
	for ($i=0; $i < $rownum; $i++)
		$phones .= $resObj[$i]->phone_number.',';


$text=urlencode($msg);
echo  $t=file_get_contents($sms_url.'?from='.$sms_number.'&to='.$phones.'&text='.$text.'&pass='.$sms_password.'&user='.$sms_user);


 	/*****NEW****/	

	 
}

function SaveNewsletter($msg){
	$db =& JFactory::getDBO();
	$query = 'INSERT INTO `#__sms_newsletters` (`newsletter`, `sent`, `sent_date`) VALUES (\''.$msg.'\', \'1\', \''.date("Y-m-d H:i:s").'\');';
	$db->setQuery($query);
	$res = $db->query();
}
	
function DeleteNewsLetter($newsletter){
	$db =& JFactory::getDBO();
	for ($i=0; $i<count($newsletter); $i++){
	$query = 'DELETE FROM `#__sms_newsletters` WHERE `id` = \''.$newsletter[$i].'\';';
	$db->setQuery($query);
	$res = $db->query();
	}
	
}

//save the subscriber into the database
function saveSubscriber($phone, $status){
	$db =& JFactory::getDBO();
	$query = 'INSERT INTO `#__sms_subscriptions` (`phone_number`, `status`) VALUES (\''.$phone.'\', \''.$status.'\');';
	$db->setQuery($query);
	$res = $db->query();
}


function editSubscriberSave($phone, $status){
	$db =& JFactory::getDBO();
	$query = 'UPDATE `#__sms_subscriptions` SET `status`=\''.$status.'\' WHERE `phone_number`=\''.$phone.'\';';
	$db->setQuery($query);
	$res = $db->query();
}

function deleteSub($cid){
	$db =& JFactory::getDBO();
	for ($i=0; $i<count($cid); $i++){
	$query = 'DELETE FROM `#__sms_subscriptions` WHERE `id` = \''.$cid[$i].'\';';
	$db->setQuery($query);
	$res = $db->query();
	}
}

}
