<?php

 
 
 
// No direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
 jimport('joomla.application.component.controller');

 
include ("htmldisplayer.smsnewsletter.php");
include ("action.smsnewsletter.php");
 

class smsnewsletterController extends JControllerLegacy
{
    /**
     * Displaying the main pages
     * of the component.
	 *
     */
	
	function display(){
	HTMLdisplayer::DisplayNewsLetters();
	}
	
	function newsletter(){
	HTMLdisplayer::DisplayNewsLetters();
	}
	 
	function subscriber(){
	HTMLdisplayer::DisplaySubscribers();
	} 
	

	
	/**
     * Displaying the create new newsletter page
     * 
	 *
     */
 
	function deleteNews(){
	$newsletter = JRequest::getVar( 'cid' , array() , '' , 'array' );  
	action::DeleteNewsLetter($newsletter);
	HTMLdisplayer::DeleteNewsletter();
	}
 
	/**
     * Displaying the page when a user clicked on the new newsletter button
     * 
	 *
     */
	function createNews(){
	HTMLdisplayer::CreateNewsLetter();
	}
 
	function cancelCreateNewsletters(){
	HTMLdisplayer::DisplayNewsLetters();
	}
	
	function sendMSG(){
	$msg = JRequest::getVar('message');
	if ($msg == ""){
		HTMLdisplayer::ErrorSendSMS();
		}else{
			action::SendSMS($msg);
			action::SaveNewsletter($msg);
			HTMLdisplayer::SendSMS();
		}
	}


	/**
     * Functions for the subscriber page
     * 
	 *
     */
	 
	 //crete subscriber page
	 
	function createSub(){
	HTMLdisplayer::createSubscriber();
	}
	
	//save the subscriber
	function saveSubscriber(){
	$phone = JRequest::getVar('phone_number');
	$status = JRequest::getVar('status');
	action::saveSubscriber($phone, $status);
	HTMLdisplayer::savesubscriber();
	}
	
	//displays edit subscriber page
	//only one subscriber can be edited one time
	// you need to click on the subscriber to edit
	function editSub(){
	$subscriber = JRequest::getVar( 'cid');  
	HTMLdisplayer::editSubscriber($subscriber[0]);
	}
	
	function editSubscriber(){
	$phone = JRequest::getVar('phone_number');
	$status = JRequest::getVar('status');
	action::editSubscriberSave($phone, $status);
	HTMLdisplayer::savesubscriber();
	}
	
	//delete subscriber page
	function deleteSub(){
	$cid = JRequest::getVar( 'cid' , array() , '' , 'array' );  
	action::deleteSub($cid);
	HTMLdisplayer::deleteSub();
	}
	
	
	//end function:
	
 
}