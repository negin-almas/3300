﻿<?php 
 
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view');
JHtml::_('behavior.multiselect');
class HTMLdisplayer{

function DisplayNewsLetters(){
JToolbarHelper::preferences('com_smsnewsletter');
JToolBarHelper::title( JText::_( 'خبرنامه مدیریت' ), 'generic.png' );
JToolBarHelper::addNew( 'createNews');

JToolBarHelper::deleteList(JText::_('  آیا از حذف خبرنامه انتخاب شده اطمینان دارید'), 'deleteNews', 'حذف');

$db =& JFactory::getDBO();
$query = 'SELECT * FROM #__sms_newsletters';
$db->setQuery($query);
$resObj = $db->loadObjectList();
$res = $db->query();
$rownum = $db->getNumRows();

?>

	<form action="index.php" method="post" name="adminForm" id="adminForm">
<div id="editcell">
    <table class="table table-striped" id="itemList">
    <thead>
        <tr>
            <th width="5">
                <?php echo JText::_( 'شناسه' ); ?>
            </th>
                <th width="1%">
                <input type="checkbox" name="checkall-toggle" value="" 
                onclick="checkAll(this)" />
                </th>
            <th>
                <?php echo JText::_( 'خبرنامه' ); ?>
            </th>
			<th>
                <?php echo JText::_( 'ارسال' ); ?>
            </th>
			<th>
                <?php echo JText::_( 'تاریخ و زمان ارسال' ); ?>
            </th>
        </tr>            
    </thead>
	
    <?php
    $k = 0;
    for ($i=0, $n=$rownum; $i < $n; $i++)
    {
     
        $checked    = JHTML::_( 'grid.id', $i, $resObj[$i]->id );
        ?>
        <tr class="row<?php echo $i % 2 ?>" >
                
            <td>
                <?php echo $i+1; ?>
            </td>
            <td class="center">
            <?php echo $checked ?>
            </td> 
            <td>
                <?php echo $resObj[$i]->newsletter; ?>
            </td>
			<td>
              <?php $issent = $resObj[$i]->sent; 
				if ($issent){
				echo "ارسال";
				}else{
				echo "عدم ارسال";
				}
			  ?>
            </td>
			<td>
              <?php echo $resObj[$i]->sent_date; ?>
            </td>
        </tr>
        <?php
        $k = 1 - $k;
    }
    ?>
    </table>
</div>
 
<input type="hidden" name="option" value="com_smsnewsletter" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="smsnewsletter" />
 
</form>

<?php
	}


//displaying the subscriber page
function DisplaySubscribers(){
//Displaying the toolbars
JToolBarHelper::title( JText::_( 'عضویت مدیریت ' ), 'generic.png' );
JToolBarHelper::addNew( 'createSub', JText::_( 'جدید' ));

JToolBarHelper::deleteList(JText::_('آیا از حذف مشترک اطمینان دارید؟'), 'deleteSub', JText::_('Delete'));


$db =& JFactory::getDBO();
$query = 'SELECT * FROM #__sms_subscriptions';
$db->setQuery($query);
$resObj = $db->loadObjectList();
$res = $db->query();
$rownum = $db->getNumRows();


?>

	<form action="index.php" method="post" name="adminForm" id="adminForm">
<div id="editcell">
    <table class="table table-striped" id="itemList">
    <thead>
        <tr>
            <th width="5">
                <?php echo JText::_( 'ID' ); ?>
            </th>
            <th width="20">
              <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo $rownum; ?>);" />
            </th>
            <th>
                <?php echo JText::_( 'خبرنامه' ); ?>
            </th>
			<th>
                <?php echo JText::_( 'وضعیت' ); ?>
            </th>
        </tr>            
    </thead>
	
    <?php
    $k = 0;
    for ($i=0, $n=$rownum; $i < $n; $i++)
    {
     
        $checked    = JHTML::_( 'grid.id', $i, $resObj[$i]->id );

        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td>
                <?php echo $i+1; ?>
            </td>
            <td>
              <?php echo $checked; ?>
            </td>
            <td>
                
				<a href="<?php echo JRoute::_('index.php?option=com_smsnewsletter&task=editSub&cid[]='.$resObj[$i]->id); ?>"><?php echo $resObj[$i]->phone_number; ?></a>
            </td>
			<td>
              <?php echo $resObj[$i]->status; ?>
            </td>
        </tr>
        <?php
        $k = 1 - $k;
    }
    ?>
    </table>
</div>
 
<input type="hidden" name="option" value="com_smsnewsletter" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="smsnewsletter" />
 
</form>

<?php
	}






//displaying the configuration page
function DisplayConfig(){
JToolBarHelper::title( JText::_( 'smspayamak.com - SMS Gateway options' ), 'generic.png' );
JToolBarHelper::save( 'saveConfig', JText::_( 'Save configuration' ));
JToolBarHelper::cancel( 'cancelConfig', JText::_( 'Cancel' ));
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div id="editcell">
    <table class="adminlist">
    <thead>
        <tr>
            <th width="5">
                <?php echo JText::_( 'ID' ); ?>
            </th>
            <th width="20">
              <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo $rownum; ?>);" />
            </th>
            <th>
                <?php echo JText::_( 'خبرنامه' ); ?>
            </th>
			<th>
                <?php echo JText::_( 'وضعیت' ); ?>
            </th>
        </tr>            
    </thead>
	
    <?php
    $k = 0;
    for ($i=0, $n=$rownum; $i < $n; $i++)
    {
     
        $checked    = JHTML::_( 'grid.id', $i, $resObj[$i]->id );
     //print_r ($checked)
        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td>
                <?php echo $i+1; ?>
            </td>
            <td>
              <?php echo $checked; ?>
            </td>
            <td>
                <?php echo $resObj[$i]->phone_number; ?>
            </td>
			<td>
              <?php echo $resObj[$i]->status; ?>
            </td>
			<td>
              <?php echo $resObj[$i]->sent_date; ?>
            </td>
        </tr>
        <?php
        $k = 1 - $k;
    }
    ?>
    </table>
</div>
 
<input type="hidden" name="option" value="com_smsnewsletter" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="smsnewsletter" />
 
</form>
<?php
}

//pages related to the Newsletter page

//"create a newsletter" page
function CreateNewsLetter(){
JToolBarHelper::title( JText::_( 'SMS Newsletter:<small>[new]</small>' ), 'generic.png' );
JToolBarHelper::save( 'sendMSG', JText::_( 'Send' ));
JToolBarHelper::cancel( 'newsletter', JText::_( 'Cancel' ));
?>
 
 
<form action="index.php?option=com_smsnewsletter" method="post" name="adminForm" id="adminForm">
      
          <table style="width:75%;" class="table table-striped" id="itemList">
      <tr>
         <th><?php echo JText::_('پیام:');?></th>
      </tr>
	  <tr>
		<td><TEXTAREA NAME="message" COLS=60 ROWS=15></TEXTAREA></td>
		</tr>
		<tr>
		<td>&nbsp;&nbsp;متن مورد نظر را نوشته و روی گزینه ارسال کلیک کنید. <br>&nbsp;&nbsp; </td>
		</tr>
      </table>
     <input type="hidden" name="option" value="com_smsnewsletter" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="controller" value="smsnewsletter" />
   </form>
 
 <?php

}

function DeleteNewsletter(){
	JControllerLegacy::setRedirect('index.php?option=com_smsnewsletter&task=newsletter');
	JFactory::getApplication()->enqueueMessage( 'Newsletter(s) Successfully deleted' );

}

//empty message error page
function ErrorSendSMS(){
	JControllerLegacy::setRedirect('index.php?option=com_smsnewsletter&task=newsletter');
	JError::raiseWarning( 100, 'Message not sent. Reason: Empty message data. Cannot send empty messages to the subscribers.' );
}

// SMS sent page
function SendSMS(){
	JControllerLegacy::setRedirect('index.php?option=com_smsnewsletter&task=newsletter');
	JFactory::getApplication()->enqueueMessage( 'Newsletter Successfully Sent');
	}


//Create subscriber page
function createSubscriber(){
	JToolBarHelper::title( JText::_( 'Newsletter Subscribers:<small>[new]</small>' ), 'generic.png' );
	JToolBarHelper::save('saveSubscriber',JText::_( 'Save' ));
	JToolBarHelper::cancel( 'subscriber', JText::_( 'Cancel' ));
	?>
	<form action="index.php" method="post" name="adminForm"  id="adminForm">
          <table style="width:75%;" class="table table-striped" id="itemList">
      <tr>
         <th><?php echo JText::_('شماره تلفن همراه: ');?></th>
      </tr>
	  <tr>
		<td><input type="text" name="phone_number" /></td>
		</tr>
		<tr>
		<td>
		<input type="radio" name="status" value="subscribed" checked> Subscribe<br>
		<input type="radio" name="status" value="unsubscribed"> Unsubscribe
		</td>
		</tr>
      </table>
     <input type="hidden" name="option" value="com_smsnewsletter" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="controller" value="smsnewsletter" />
   </form>
   <?php
	}
	
function saveSubscriber(){
	JControllerLegacy::setRedirect('index.php?option=com_smsnewsletter&task=subscriber');
	JFactory::getApplication()->enqueueMessage( 'Subscriber Saved Successfully');
}
	
function editSubscriber($subscriber){
	JToolBarHelper::title( JText::_( 'Newsletter Subscribers:<small>[edit]</small>' ), 'generic.png' );
	JToolBarHelper::save('editSubscriber',JText::_( 'Save' ));
	JToolBarHelper::cancel( 'subscriber', JText::_( 'Cancel' ));
	
	//select the subscriber number and the status from the database
	$db =& JFactory::getDBO();
	$query = "SELECT phone_number,status FROM #__sms_subscriptions WHERE id='$subscriber'";
	$db->setQuery($query);
	$resObj = $db->loadObjectList();
	
	$phone_number = $resObj[0]->phone_number;
	$status = $resObj[0]->status;
	?>
	<form action="index.php" method="post" name="adminForm"  id="adminForm">
          <table style="width:75%;" class="table table-striped" id="itemList">
      <tr>
         <th><?php echo JText::_('شماره تلفن همراه: ');?></th>
      </tr>
	  <tr>
		<td><b><?php echo $phone_number; ?></b></td>
		</tr>
		<tr>
		<td>
		<?php 
		
		if ($status == 'subscribed'){ ?>
		<input type="radio" name="status" value="subscribed" checked> Subscribe<br>
		<input type="radio" name="status" value="unsubscribed"> Unsubscribe
		<?php
		}elseif ($status == 'unsubscribed'){ ?>
		<input type="radio" name="status" value="subscribed"> Subscribe<br>
		<input type="radio" name="status" value="unsubscribed" checked> Unsubscribe
		<?php	}?>
		</td>
		</tr>
      </table>
	  
	  <input type="hidden" name="phone_number" value="<?php echo $phone_number;?>" />
     <input type="hidden" name="option" value="com_smsnewsletter" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="controller" value="smsnewsletter" />
   </form>
   <?php
}
	
function deleteSub(){
	JControllerLegacy::setRedirect('index.php?option=com_smsnewsletter&task=subscriber');
	JFactory::getApplication()->enqueueMessage( 'Subscriber(s) Successfully deleted' );

}	
	
	
//end class
}