<?php

 
 
// No direct access

defined( '_JEXEC' ) or die;
if (!defined('DS')) {
    define('DS', DIRECTORY_SEPARATOR);
}
jimport('joomla.application.component.controller');


require_once( JPATH_COMPONENT.DS.'controller.smsnewsletter.php' );
$controller = new smsnewsletterController;
$controller->execute(JRequest::getVar('task'));
$controller->redirect();
?>