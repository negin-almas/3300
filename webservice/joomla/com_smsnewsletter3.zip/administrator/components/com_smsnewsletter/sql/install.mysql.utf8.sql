CREATE TABLE IF NOT EXISTS `#__sms_newsletters` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `newsletter` varchar(320) NOT NULL,
  `sent` tinyint(1) NOT NULL,
  `sent_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `#__sms_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone_number` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;
