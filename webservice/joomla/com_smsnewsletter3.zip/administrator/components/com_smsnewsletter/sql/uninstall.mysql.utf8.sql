		DROP TABLE `#__sms_newsletters`;
		DROP TABLE `#__sms_subscriptions`;
