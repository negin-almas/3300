﻿<?php

 

// no direct access
defined('_JEXEC') or die('Restricted access');

class modsmsNotificationHelper
{

//This function checks if the user is already subscribed
function smsCheckStatus($phonenum){
	global $mainframe;
	$database=& JFactory::getDBO();
	$q = 'SELECT `status` FROM `#__sms_subscriptions` WHERE  phone_number = \'' . $phonenum . '\'';
	$database->setQuery( $q );	
	
	if (!($database->loadResult())){
		return true; //returns true if the user can subscribe
		}
		else 
			if (($database->loadResult()) == 'unsubscribed')
				return true;
			elseif (($database->loadResult()) == 'subscribed')
				return false; //returns false if the user is already subscribed
}

function smsNewsletterSubscribe($phonenum){
	global $mainframe;
	
	$database=& JFactory::getDBO();
	$q = 'SELECT `status` FROM `#__sms_subscriptions` WHERE  phone_number = \'' . $phonenum . '\'';
	$database->setQuery( $q );	
	if (!($database->loadResult())){ //if the phone number is not yet in the database
			$query = 'INSERT INTO `#__sms_subscriptions`(`phone_number` , `status`) VALUES (\'' . $phonenum . '\' , \'subscribed\')';
			$database->setQuery($query);
			$database->query();
		}
		elseif (($database->loadResult()) == unsubscribed){ //if the phone number is in the database, but unsubscribed
			$query = 'UPDATE `#__sms_subscriptions` SET `status` = \'subscribed\' WHERE phone_number = \'' . $phonenum . '\';';
			$database->setQuery($query);
			$database->query();
		}
	echo 'از این که در خبرنامه پیامکی ما عضو شدید سپاس گزاریم';
}	

function smsNewsletterUnsubscribe($phonenum){
	global $mainframe;
	$database=& JFactory::getDBO();
	$query = 'UPDATE `#__sms_subscriptions` SET `status` = \'unsubscribed\' WHERE phone_number = \'' . $phonenum . '\';';
	$database->setQuery($query);
			$database->query();
				echo 'عضویت شما در خبرنامه پیامکی ما لغو شد';

}	

	function smsSendSMS($phone, $msg, $params){
	$debug = false;
	$sms_num = $params->get('sms_number');
	$sms_user = $params->get('sms_user');
	$sms_password = $params->get('sms_password');
	$sms_flash = $params->get('flash');
	$sms_urlapi = $params->get('sms_api');
	$text=urlencode($msg);
	return   $t=file_get_contents('http://sms.3300.ir/sendsms.ashx?from='.$sms_num.'&to='.$phone.'&text='.$text.'&pass='.$sms_password.'&user='.$sms_user);
 



	/*****NEW****/	

	}
}
