<?php

 
defined('_JEXEC') or die('Restricted access');
if (!defined('DS')) {
    define('DS', DIRECTORY_SEPARATOR);
}
  
require_once( dirname(__FILE__).DS.'helper.php');
require_once(JModuleHelper::getLayoutPath('mod_smsnewsletter'));




