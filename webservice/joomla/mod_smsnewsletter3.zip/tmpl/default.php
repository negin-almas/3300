﻿<?php 


 

defined('_JEXEC') or die('Direct access is forbidden!');

	$sms_div= '<div class="sms_send"><form method=post action="">';
	$sms_div.= '<p> شماره همراه: <input type="text" name="smsSubscribeNumber"></p> ';
	$sms_div.= '<input type="radio" name="smsSubscribeStatus" value="subscribe" checked> عضویت ';
	$sms_div .= '<br/><input type="radio" name="smsSubscribeStatus" value="unsubscribe"> لغو عضویت<br>';
	$sms_div.= '<p><input type="submit" name="save" value="  ثبت اطلاعات "></p></form></div>';
	echo $sms_div;

	
	
if (!isset($_POST['smsSubscribeNumber'])){
	echo 'لطفا شماره خود را بدرستی وارد نمائید!';
	
	}else{
	if (($_POST['smsSubscribeStatus']) == 'subscribe'){ //this case the user want to subscribe
		if ((preg_match('/^[+].[0-9].*$/',$_POST['smsSubscribeNumber'])) || (preg_match('/^[0-9].*$/',$_POST['smsSubscribeNumber']))){
			$welcome_message = $params->get('subscription_message_enable');
			
			if (!(modsmsNotificationHelper::smsCheckStatus($_POST['smsSubscribeNumber'])))  		//check the subscription status
					echo ' شماره شما در خبرنامه سایت موجود میباشد.  '; 
				elseif ((modsmsNotificationHelper::smsCheckStatus($_POST['smsSubscribeNumber']))) //if the smsCheckStatus returns true, the user can subscribe to the newsletter.
				{	modsmsNotificationHelper::smsNewsletterSubscribe($_POST['smsSubscribeNumber']); 	//subscribes to the newsletter
					if ($welcome_message) {
						$msg = $params -> get('subscription_message');
						//sends the welcome message if it is enabled
						modsmsNotificationHelper::smsSendSMS($_POST['smsSubscribeNumber'], $params -> get('subscription_message'), $params);
					}
				}
					
		}else {
			echo 'Invalid phone number! Please use the international phone number format!';
		}
	}	elseif (($_POST['smsSubscribeStatus']) == 'unsubscribe'){ //this case the user wants to unsubscribe
			$bye_message = $params->get('unsubscription_message_enable');
			modsmsNotificationHelper::smsNewsletterUnsubscribe($_POST['smsSubscribeNumber']);
			if ($bye_message){
			modsmsNotificationHelper::smsSendSMS($_POST['smsSubscribeNumber'], $params -> get('unsubscription_message'), $params);
			}
		}
	}

?>
