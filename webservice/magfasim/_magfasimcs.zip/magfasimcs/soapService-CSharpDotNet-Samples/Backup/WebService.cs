using System;
using System.Drawing;
using System.Net;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Web;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Configuration;

namespace ProxyWS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class WebService : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnSend;
		private System.Windows.Forms.TextBox txtMobile;
		private System.Windows.Forms.TextBox txtMessage;
		//private WebProxy proxy;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label result1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public WebService()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.btnSend = new System.Windows.Forms.Button();
            this.txtMobile = new System.Windows.Forms.TextBox();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.result1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(96, 58);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 0;
            this.btnSend.Text = "Send";
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtMobile
            // 
            this.txtMobile.Location = new System.Drawing.Point(96, 6);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(160, 20);
            this.txtMobile.TabIndex = 1;
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(96, 32);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(160, 20);
            this.txtMessage.TabIndex = 2;
            this.txtMessage.Text = "Test For Web Service";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(18, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 23);
            this.label1.TabIndex = 3;
            this.label1.Text = "Mobile";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(18, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 23);
            this.label2.TabIndex = 4;
            this.label2.Text = "Message";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(18, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Result:";
            // 
            // result1
            // 
            this.result1.Location = new System.Drawing.Point(93, 86);
            this.result1.Name = "result1";
            this.result1.Size = new System.Drawing.Size(163, 132);
            this.result1.TabIndex = 7;
            // 
            // WebService
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(272, 229);
            this.Controls.Add(this.result1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.txtMobile);
            this.Controls.Add(this.btnSend);
            this.ForeColor = System.Drawing.Color.Azure;
            this.Name = "WebService";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new WebService());
		}

		private void btnSend_Click(object sender, System.EventArgs e)
		{
			result1.Text = "Sending...";
            Form.ActiveForm.Refresh();
			string message = txtMessage.Text ;
			string phone = txtMobile.Text ;
            WebProxy proxy;

            proxy = new WebProxy(System.Configuration.ConfigurationSettings.AppSettings["ProxyAddress"]);
            proxy.Credentials = new NetworkCredential(System.Configuration.ConfigurationSettings.AppSettings["ProxyUsername"], System.Configuration.ConfigurationSettings.AppSettings["ProxyPassword"]);
         
			SOAPSmsQueue.SoapSmsQueuableImplementationService sq = new SOAPSmsQueue.SoapSmsQueuableImplementationService();
            if (System.Configuration.ConfigurationSettings.AppSettings["UseProxy"] == "yes")
            {
                sq.Proxy = proxy;
            }
			string username = System.Configuration.ConfigurationSettings.AppSettings["Username"];
			string password = System.Configuration.ConfigurationSettings.AppSettings["Password"];
			string domain = System.Configuration.ConfigurationSettings.AppSettings["Domain"];
			sq.Credentials = new System.Net.NetworkCredential(username, password);
            sq.PreAuthenticate = true;
			long[] results;

            string[] messages;
			string[] mobiles;
			string[] origs;

            int[] encodings;
            string[] UDH;
            int[] mclass;
            int[] priorities;
            long[] checkingIds;

            int N = Int32.Parse(System.Configuration.ConfigurationSettings.AppSettings["Count"]);
			messages = new string[N];
			mobiles = new string[N];
			origs = new string[N];

            encodings = new int[N];
            UDH = new string[N];
            mclass = new int[N];
            priorities = new int[N];
            checkingIds = new long[N];
            /*
            encodings = null;
            UDH = null;
            mclass = null;
            priorities = null;
            checkingIds = null;
            */
            for(int i=0; i<N; i++)
            {
			    messages[i] = txtMessage.Text;
			    mobiles[i] = txtMobile.Text;
			    origs[i] = System.Configuration.ConfigurationSettings.AppSettings["SenderNumber"];

                encodings[i] = -1;
                UDH[i] = "";
                mclass[i] = -1;
                priorities[i] = -1;
                checkingIds[i] = 200+i;
            }

            results = sq.enqueue(domain, messages, mobiles, origs, encodings, UDH, mclass, priorities, checkingIds);
            //results = sq.getCredit();
            result1.Text = "";
            for (int i = 0; i < N; i++)
            {
                result1.Text += results[i].ToString()+"\n";
            }
		}

        private void Form1_Load(object sender, EventArgs e)
        {

        }
	}
}
