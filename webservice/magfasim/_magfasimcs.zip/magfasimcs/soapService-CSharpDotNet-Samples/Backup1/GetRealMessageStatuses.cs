﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;

namespace ProxyWS
{
    class GetRealMessageStatusesSample
    {
        public int[] getRealMessageStatuses(Boolean useProxy, String proxyAddress, String proxyUsername, String proxyPassword, String username, String password, long[] messageIds)
        {
            MagfaWebReference.SoapSmsQueuableImplementationService sq = new MagfaWebReference.SoapSmsQueuableImplementationService();
            if (useProxy)
            {
                WebProxy proxy;
                proxy = new WebProxy(proxyAddress);
                proxy.Credentials = new NetworkCredential(proxyUsername, proxyPassword);
                sq.Proxy = proxy;
            }
            sq.Credentials = new System.Net.NetworkCredential(username, password);
            sq.PreAuthenticate = true;
            return sq.getRealMessageStatuses(messageIds);
        }
    }
}
