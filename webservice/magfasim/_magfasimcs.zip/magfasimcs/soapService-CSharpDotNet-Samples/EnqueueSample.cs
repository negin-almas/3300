﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Configuration;

namespace ProxyWS
{
    class EnqueueSample
    {
        public long[] enqueue(Boolean useProxy, String proxyAddress, String proxyUsername, String proxyPassword, String username, String password, String domain, int count, String senderNumber, String recipientNumber, String text)
        {
            MagfaWebReference.SoapSmsQueuableImplementationService sq = new MagfaWebReference.SoapSmsQueuableImplementationService();
            if (useProxy)
            {
                WebProxy proxy;
                proxy = new WebProxy(proxyAddress);
                proxy.Credentials = new NetworkCredential(proxyUsername, proxyPassword);
                sq.Proxy = proxy;
            }
            sq.Credentials = new System.Net.NetworkCredential(username, password);
            sq.PreAuthenticate = true;
            long[] results;

            string[] messages;
            string[] mobiles;
            string[] origs;

            int[] encodings;
            string[] UDH;
            int[] mclass;
            int[] priorities;
            long[] checkingIds;

            messages = new string[count];
            mobiles = new string[count];
            origs = new string[count];

            encodings = new int[count];
            UDH = new string[count];
            mclass = new int[count];
            priorities = new int[count];
            checkingIds = new long[count];
            /*
            encodings = null;
            UDH = null;
            mclass = null;
            priorities = null;
            checkingIds = null;
            */
            for (int i = 0; i < count; i++)
            {
                messages[i] = text;
                mobiles[i] = recipientNumber;
                origs[i] = senderNumber;

                encodings[i] = -1;
                UDH[i] = "";
                mclass[i] = 0;
                priorities[i] = -1;
                checkingIds[i] = 200 + i;
            }

            return sq.enqueue(domain, messages, mobiles, origs, encodings, UDH, mclass, priorities, checkingIds);
        }
    }

    
}
