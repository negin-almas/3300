﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;

namespace ProxyWS
{
    class GetAllMessagesWithNumberSample
    {
        public MagfaWebReference.CustomerReturnIncomingFormat[] getAllMessagesWithNumber(Boolean useProxy, String proxyAddress, String proxyUsername, String proxyPassword, String username, String password, String domain, int numberOfMessages, String destNumber)
        {
            MagfaWebReference.SoapSmsQueuableImplementationService sq = new MagfaWebReference.SoapSmsQueuableImplementationService();
            if (useProxy)
            {
                WebProxy proxy;
                proxy = new WebProxy(proxyAddress);
                proxy.Credentials = new NetworkCredential(proxyUsername, proxyPassword);
                sq.Proxy = proxy;
            }
            sq.Credentials = new System.Net.NetworkCredential(username, password);
            sq.PreAuthenticate = true;
            System.Object[] shit = sq.getAllMessagesWithNumber(domain, numberOfMessages, destNumber);
            MagfaWebReference.CustomerReturnIncomingFormat[] custs = new MagfaWebReference.CustomerReturnIncomingFormat[shit.Length];
            for (int index = 0; index < shit.Length; index++)
            {
                custs[index] = (MagfaWebReference.CustomerReturnIncomingFormat)shit[index];
            }
            return custs;
        }
    }
}
