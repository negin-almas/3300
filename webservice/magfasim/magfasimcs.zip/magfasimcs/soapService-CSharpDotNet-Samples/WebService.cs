using System;
using System.Drawing;
using System.Net;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Web;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Configuration;

namespace ProxyWS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class WebService : System.Windows.Forms.Form
    {
        private TabPage getAllMessagesWithNumberTabPage;
        private TabPage tabPage4;
        private Label label7;
        private Button getAllMessagesButton;
        private TabPage getMessageStatusesTabPage;
        private Button getStatusButton;
        private GroupBox realStatusGroupBox;
        private GroupBox statusGroupBox;
        private TextBox MessageIdTextBox;
        private Label label6;
        private TabPage getMessageIdTabPage;
        private Label label5;
        private Label label4;
        private Button getMessageIdButton;
        private TextBox textBox1;
        private TabPage tabPage2;
        private Label creditLabel;
        private Button getCreditButton;
        private TabPage enqueueTab;
        private Label result1;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtMessage;
        private TextBox txtMobile;
        private Button btnSend;
        private TabControl webserviceSamples;
        private Label label9;
        private Button button1;
        private TextBox textBox2;
        private Label label8;
        //private WebProxy proxy;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

        private readonly String username;
        private readonly String password;
        private readonly String domain;
        private readonly String senderNumber;
        
        private readonly int N;
        
        private readonly bool useProxy;
        private readonly String proxyAddress;
        private readonly String proxyUsername;
        private Label realStatusLabel;
        private Label statusLabel;
        private readonly String proxyPassword;

		public WebService()
		{
            username = System.Configuration.ConfigurationSettings.AppSettings["Username"];
            password = System.Configuration.ConfigurationSettings.AppSettings["Password"];
            domain = System.Configuration.ConfigurationSettings.AppSettings["Domain"];
            N = Int32.Parse(System.Configuration.ConfigurationSettings.AppSettings["Count"]);
            senderNumber = System.Configuration.ConfigurationSettings.AppSettings["SenderNumber"];
            
            useProxy = bool.Parse(System.Configuration.ConfigurationSettings.AppSettings["UseProxy"]);
            proxyAddress = System.Configuration.ConfigurationSettings.AppSettings["ProxyAddress"];
            proxyUsername = System.Configuration.ConfigurationSettings.AppSettings["ProxyUsername"];
            proxyPassword = System.Configuration.ConfigurationSettings.AppSettings["ProxyPassword"];
            
            //
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.getAllMessagesWithNumberTabPage = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.getAllMessagesButton = new System.Windows.Forms.Button();
            this.getMessageStatusesTabPage = new System.Windows.Forms.TabPage();
            this.getStatusButton = new System.Windows.Forms.Button();
            this.realStatusGroupBox = new System.Windows.Forms.GroupBox();
            this.realStatusLabel = new System.Windows.Forms.Label();
            this.statusGroupBox = new System.Windows.Forms.GroupBox();
            this.statusLabel = new System.Windows.Forms.Label();
            this.MessageIdTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.getMessageIdTabPage = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.getMessageIdButton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.creditLabel = new System.Windows.Forms.Label();
            this.getCreditButton = new System.Windows.Forms.Button();
            this.enqueueTab = new System.Windows.Forms.TabPage();
            this.result1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.txtMobile = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.webserviceSamples = new System.Windows.Forms.TabControl();
            this.getAllMessagesWithNumberTabPage.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.getMessageStatusesTabPage.SuspendLayout();
            this.realStatusGroupBox.SuspendLayout();
            this.statusGroupBox.SuspendLayout();
            this.getMessageIdTabPage.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.enqueueTab.SuspendLayout();
            this.webserviceSamples.SuspendLayout();
            this.SuspendLayout();
            // 
            // getAllMessagesWithNumberTabPage
            // 
            this.getAllMessagesWithNumberTabPage.Controls.Add(this.label9);
            this.getAllMessagesWithNumberTabPage.Controls.Add(this.button1);
            this.getAllMessagesWithNumberTabPage.Controls.Add(this.textBox2);
            this.getAllMessagesWithNumberTabPage.Controls.Add(this.label8);
            this.getAllMessagesWithNumberTabPage.Location = new System.Drawing.Point(4, 22);
            this.getAllMessagesWithNumberTabPage.Name = "getAllMessagesWithNumberTabPage";
            this.getAllMessagesWithNumberTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.getAllMessagesWithNumberTabPage.Size = new System.Drawing.Size(664, 283);
            this.getAllMessagesWithNumberTabPage.TabIndex = 5;
            this.getAllMessagesWithNumberTabPage.Text = "Get All Messages (With Number)";
            this.getAllMessagesWithNumberTabPage.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(6, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Results: ";
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(218, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(165, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Get All Messages With Number";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(112, 6);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(6, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Destination Number";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.getAllMessagesButton);
            this.tabPage4.ForeColor = System.Drawing.Color.Black;
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(664, 283);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "Get All Messages";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Results: ";
            // 
            // getAllMessagesButton
            // 
            this.getAllMessagesButton.Location = new System.Drawing.Point(6, 6);
            this.getAllMessagesButton.Name = "getAllMessagesButton";
            this.getAllMessagesButton.Size = new System.Drawing.Size(154, 23);
            this.getAllMessagesButton.TabIndex = 0;
            this.getAllMessagesButton.Text = "Get 2 Incoming Messages";
            this.getAllMessagesButton.UseVisualStyleBackColor = true;
            this.getAllMessagesButton.Click += new System.EventHandler(this.getAllMessagesButton_Click);
            // 
            // getMessageStatusesTabPage
            // 
            this.getMessageStatusesTabPage.Controls.Add(this.getStatusButton);
            this.getMessageStatusesTabPage.Controls.Add(this.realStatusGroupBox);
            this.getMessageStatusesTabPage.Controls.Add(this.statusGroupBox);
            this.getMessageStatusesTabPage.Controls.Add(this.MessageIdTextBox);
            this.getMessageStatusesTabPage.Controls.Add(this.label6);
            this.getMessageStatusesTabPage.Location = new System.Drawing.Point(4, 22);
            this.getMessageStatusesTabPage.Name = "getMessageStatusesTabPage";
            this.getMessageStatusesTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.getMessageStatusesTabPage.Size = new System.Drawing.Size(664, 283);
            this.getMessageStatusesTabPage.TabIndex = 3;
            this.getMessageStatusesTabPage.Text = "Get Message Statuses";
            this.getMessageStatusesTabPage.UseVisualStyleBackColor = true;
            // 
            // getStatusButton
            // 
            this.getStatusButton.ForeColor = System.Drawing.Color.Black;
            this.getStatusButton.Location = new System.Drawing.Point(188, 4);
            this.getStatusButton.Name = "getStatusButton";
            this.getStatusButton.Size = new System.Drawing.Size(75, 23);
            this.getStatusButton.TabIndex = 2;
            this.getStatusButton.Text = "Get Status";
            this.getStatusButton.UseVisualStyleBackColor = true;
            this.getStatusButton.Click += new System.EventHandler(this.getStatusButton_Click);
            // 
            // realStatusGroupBox
            // 
            this.realStatusGroupBox.Controls.Add(this.realStatusLabel);
            this.realStatusGroupBox.ForeColor = System.Drawing.Color.Black;
            this.realStatusGroupBox.Location = new System.Drawing.Point(9, 162);
            this.realStatusGroupBox.Name = "realStatusGroupBox";
            this.realStatusGroupBox.Size = new System.Drawing.Size(649, 112);
            this.realStatusGroupBox.TabIndex = 4;
            this.realStatusGroupBox.TabStop = false;
            this.realStatusGroupBox.Text = "Real Message Status";
            // 
            // realStatusLabel
            // 
            this.realStatusLabel.AutoSize = true;
            this.realStatusLabel.Location = new System.Drawing.Point(6, 16);
            this.realStatusLabel.Name = "realStatusLabel";
            this.realStatusLabel.Size = new System.Drawing.Size(45, 13);
            this.realStatusLabel.TabIndex = 0;
            this.realStatusLabel.Text = "Results:";
            // 
            // statusGroupBox
            // 
            this.statusGroupBox.Controls.Add(this.statusLabel);
            this.statusGroupBox.ForeColor = System.Drawing.Color.Black;
            this.statusGroupBox.Location = new System.Drawing.Point(9, 33);
            this.statusGroupBox.Name = "statusGroupBox";
            this.statusGroupBox.Size = new System.Drawing.Size(649, 115);
            this.statusGroupBox.TabIndex = 3;
            this.statusGroupBox.TabStop = false;
            this.statusGroupBox.Text = "Message Status";
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Location = new System.Drawing.Point(6, 16);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(45, 13);
            this.statusLabel.TabIndex = 0;
            this.statusLabel.Text = "Results:";
            // 
            // MessageIdTextBox
            // 
            this.MessageIdTextBox.Location = new System.Drawing.Point(82, 6);
            this.MessageIdTextBox.Name = "MessageIdTextBox";
            this.MessageIdTextBox.Size = new System.Drawing.Size(100, 20);
            this.MessageIdTextBox.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(6, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Message ID: ";
            // 
            // getMessageIdTabPage
            // 
            this.getMessageIdTabPage.Controls.Add(this.label5);
            this.getMessageIdTabPage.Controls.Add(this.label4);
            this.getMessageIdTabPage.Controls.Add(this.getMessageIdButton);
            this.getMessageIdTabPage.Controls.Add(this.textBox1);
            this.getMessageIdTabPage.Location = new System.Drawing.Point(4, 22);
            this.getMessageIdTabPage.Name = "getMessageIdTabPage";
            this.getMessageIdTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.getMessageIdTabPage.Size = new System.Drawing.Size(664, 283);
            this.getMessageIdTabPage.TabIndex = 2;
            this.getMessageIdTabPage.Text = "Get Message ID";
            this.getMessageIdTabPage.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(6, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Results:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(6, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Checking Message ID: ";
            // 
            // getMessageIdButton
            // 
            this.getMessageIdButton.ForeColor = System.Drawing.Color.Black;
            this.getMessageIdButton.Location = new System.Drawing.Point(236, 4);
            this.getMessageIdButton.Name = "getMessageIdButton";
            this.getMessageIdButton.Size = new System.Drawing.Size(96, 23);
            this.getMessageIdButton.TabIndex = 1;
            this.getMessageIdButton.Text = "Get Message ID";
            this.getMessageIdButton.UseVisualStyleBackColor = true;
            this.getMessageIdButton.Click += new System.EventHandler(this.getMessageIdButton_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(130, 6);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.creditLabel);
            this.tabPage2.Controls.Add(this.getCreditButton);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(664, 283);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "getCredit";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // creditLabel
            // 
            this.creditLabel.AutoSize = true;
            this.creditLabel.ForeColor = System.Drawing.Color.Black;
            this.creditLabel.Location = new System.Drawing.Point(147, 11);
            this.creditLabel.Name = "creditLabel";
            this.creditLabel.Size = new System.Drawing.Size(39, 13);
            this.creditLabel.TabIndex = 1;
            this.creditLabel.Text = "credit: ";
            this.creditLabel.Click += new System.EventHandler(this.label4_Click);
            // 
            // getCreditButton
            // 
            this.getCreditButton.ForeColor = System.Drawing.Color.Black;
            this.getCreditButton.Location = new System.Drawing.Point(6, 6);
            this.getCreditButton.Name = "getCreditButton";
            this.getCreditButton.Size = new System.Drawing.Size(135, 23);
            this.getCreditButton.TabIndex = 0;
            this.getCreditButton.Text = "Get Credit";
            this.getCreditButton.UseVisualStyleBackColor = true;
            this.getCreditButton.Click += new System.EventHandler(this.getCreditButton_Click);
            // 
            // enqueueTab
            // 
            this.enqueueTab.BackColor = System.Drawing.Color.Transparent;
            this.enqueueTab.Controls.Add(this.result1);
            this.enqueueTab.Controls.Add(this.label3);
            this.enqueueTab.Controls.Add(this.label2);
            this.enqueueTab.Controls.Add(this.label1);
            this.enqueueTab.Controls.Add(this.txtMessage);
            this.enqueueTab.Controls.Add(this.txtMobile);
            this.enqueueTab.Controls.Add(this.btnSend);
            this.enqueueTab.ForeColor = System.Drawing.Color.Black;
            this.enqueueTab.Location = new System.Drawing.Point(4, 22);
            this.enqueueTab.Name = "enqueueTab";
            this.enqueueTab.Padding = new System.Windows.Forms.Padding(3);
            this.enqueueTab.Size = new System.Drawing.Size(664, 283);
            this.enqueueTab.TabIndex = 0;
            this.enqueueTab.Text = "Enqueue";
            this.enqueueTab.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // result1
            // 
            this.result1.Location = new System.Drawing.Point(81, 89);
            this.result1.Name = "result1";
            this.result1.Size = new System.Drawing.Size(425, 191);
            this.result1.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(6, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 13;
            this.label3.Text = "Result:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(6, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 23);
            this.label2.TabIndex = 12;
            this.label2.Text = "Message";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(6, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 23);
            this.label1.TabIndex = 11;
            this.label1.Text = "Mobile";
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(84, 37);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(160, 20);
            this.txtMessage.TabIndex = 10;
            this.txtMessage.Text = "Test For Web Service";
            // 
            // txtMobile
            // 
            this.txtMobile.Location = new System.Drawing.Point(84, 11);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(160, 20);
            this.txtMobile.TabIndex = 9;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(84, 63);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 8;
            this.btnSend.Text = "Send";
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // webserviceSamples
            // 
            this.webserviceSamples.Controls.Add(this.enqueueTab);
            this.webserviceSamples.Controls.Add(this.tabPage2);
            this.webserviceSamples.Controls.Add(this.getMessageIdTabPage);
            this.webserviceSamples.Controls.Add(this.getMessageStatusesTabPage);
            this.webserviceSamples.Controls.Add(this.tabPage4);
            this.webserviceSamples.Controls.Add(this.getAllMessagesWithNumberTabPage);
            this.webserviceSamples.Location = new System.Drawing.Point(12, 12);
            this.webserviceSamples.Name = "webserviceSamples";
            this.webserviceSamples.SelectedIndex = 0;
            this.webserviceSamples.Size = new System.Drawing.Size(672, 309);
            this.webserviceSamples.TabIndex = 0;
            // 
            // WebService
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(696, 333);
            this.Controls.Add(this.webserviceSamples);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "WebService";
            this.Text = "MAGFA Webservice Samples";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.getAllMessagesWithNumberTabPage.ResumeLayout(false);
            this.getAllMessagesWithNumberTabPage.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.getMessageStatusesTabPage.ResumeLayout(false);
            this.getMessageStatusesTabPage.PerformLayout();
            this.realStatusGroupBox.ResumeLayout(false);
            this.realStatusGroupBox.PerformLayout();
            this.statusGroupBox.ResumeLayout(false);
            this.statusGroupBox.PerformLayout();
            this.getMessageIdTabPage.ResumeLayout(false);
            this.getMessageIdTabPage.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.enqueueTab.ResumeLayout(false);
            this.enqueueTab.PerformLayout();
            this.webserviceSamples.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new WebService());
		}

		/*private void btnSend_Click(object sender, System.EventArgs e)
		{
			result1.Text = "Sending...";
            Form.ActiveForm.Refresh();
			string message = txtMessage.Text ;
			string phone = txtMobile.Text ;
            WebProxy proxy;

            proxy = new WebProxy(System.Configuration.ConfigurationSettings.AppSettings["ProxyAddress"]);
            proxy.Credentials = new NetworkCredential(System.Configuration.ConfigurationSettings.AppSettings["ProxyUsername"], System.Configuration.ConfigurationSettings.AppSettings["ProxyPassword"]);
         
			SOAPSmsQueue.SoapSmsQueuableImplementationService sq = new SOAPSmsQueue.SoapSmsQueuableImplementationService();
            if (System.Configuration.ConfigurationSettings.AppSettings["UseProxy"] == "yes")
            {
                sq.Proxy = proxy;
            }
			string username = System.Configuration.ConfigurationSettings.AppSettings["Username"];
			string password = System.Configuration.ConfigurationSettings.AppSettings["Password"];
			string domain = System.Configuration.ConfigurationSettings.AppSettings["Domain"];
			sq.Credentials = new System.Net.NetworkCredential(username, password);
            sq.PreAuthenticate = true;
			long[] results;

            string[] messages;
			string[] mobiles;
			string[] origs;

            int[] encodings;
            string[] UDH;
            int[] mclass;
            int[] priorities;
            long[] checkingIds;

            int N = Int32.Parse(System.Configuration.ConfigurationSettings.AppSettings["Count"]);
			messages = new string[N];
			mobiles = new string[N];
			origs = new string[N];

            encodings = new int[N];
            UDH = new string[N];
            mclass = new int[N];
            priorities = new int[N];
            checkingIds = new long[N];
            
            encodings = null;
            UDH = null;
            mclass = null;
            priorities = null;
            checkingIds = null;
            
            for(int i=0; i<N; i++)
            {
			    messages[i] = txtMessage.Text;
			    mobiles[i] = txtMobile.Text;
			    origs[i] = System.Configuration.ConfigurationSettings.AppSettings["SenderNumber"];

                encodings[i] = -1;
                UDH[i] = "";
                mclass[i] = -1;
                priorities[i] = -1;
                checkingIds[i] = 200+i;
            }

            results = sq.enqueue(domain, messages, mobiles, origs, encodings, UDH, mclass, priorities, checkingIds);
            //results = sq.getCredit();
            result1.Text = "";
            for (int i = 0; i < N; i++)
            {
                result1.Text += results[i].ToString()+"\n";
            }
		}*/

        private void btnSend_Click(object sender, System.EventArgs e)
        {
            try
            {
                result1.Text = "Sending...";
                Form.ActiveForm.Refresh();
                long result = (new EnqueueSample()).enqueue(useProxy, proxyAddress, proxyUsername, proxyPassword, username, password, domain, N, senderNumber, txtMobile.Text, txtMessage.Text)[0];
                if (result < ErrorCodes.MAX_VALUE)
                    result1.Text = generateDateString() + "Error code: " + result + ", " + ErrorCodes.getDescriptionForCode((int)result);
                else
                    result1.Text = generateDateString() + result;
            }
            catch (Exception exception)
            {
                result1.Text = generateDateString() + "Exception occurred: " + (exception);
            }
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void getCreditButton_Click(object sender, EventArgs e)
        {
            try
            {
                creditLabel.Text = "Sending...";
                Form.ActiveForm.Refresh();
                float result = (new GetCreditSample()).getCredit(useProxy, proxyAddress, proxyUsername, proxyPassword, username, password, domain);
                if (result < ErrorCodes.MAX_VALUE)
                    creditLabel.Text = generateDateString() + "You may have caught an error, value: " + result + ", " + ErrorCodes.getDescriptionForCode((int)result);
                else
                    creditLabel.Text = generateDateString() + "your credit: " + result;
            }
            catch (Exception exception)
            {
                creditLabel.Text = generateDateString() + "Exception occurred: " + (exception);
            }
        }

        private String generateDateString()
        {
            return "[" + System.DateTime.Now.ToLongTimeString() + "]  -  "; 
        }

        private void getMessageIdButton_Click(object sender, EventArgs e)
        {
            try
            {
                label5.Text = "Sending...";
                Form.ActiveForm.Refresh();
                long result = (new GetMessageIdSample()).GetMessageId(useProxy, proxyAddress, proxyUsername, proxyPassword, username, password, domain, long.Parse(textBox1.Text));
                if (result < ErrorCodes.MAX_VALUE)
                    label5.Text = generateDateString() + "You may have caught an error, code: " + result + ", " + ErrorCodes.getDescriptionForCode((int)result);
                else
                    label5.Text = "Results: " + generateDateString() + Convert.ToString(result);
            }
            catch (Exception exception)
            {
                label5.Text = generateDateString() + "Exception occurred: " + (exception);
            }
        }

        private void getStatusButton_Click(object sender, EventArgs e)
        {
            try
            {
                statusLabel.Text = "Sending...";
                realStatusLabel.Text = "Sending...";
                Form.ActiveForm.Refresh();

                long[] messageIds = new long[1];
                messageIds[0] = long.Parse(MessageIdTextBox.Text);
                
                int statusResults = (new GetMessageStatusesSample()).getMessageStatuses(useProxy, proxyAddress, proxyUsername, proxyPassword, username, password, messageIds)[0];
                if (statusResults <= -1)
                    statusLabel.Text = "Error. code: " + statusResults + ", " + ErrorCodes.getDescriptionForCode(statusResults);
                else
                    statusLabel.Text = "Results: " + generateDateString() + statusResults;
                
                int realStatusResults = (new GetRealMessageStatusesSample()).getRealMessageStatuses(useProxy, proxyAddress, proxyUsername, proxyPassword, username, password, messageIds)[0];
                if(realStatusResults <= -1)
                    realStatusLabel.Text = "Error. code: " + realStatusLabel + ", " + ErrorCodes.getDescriptionForCode(realStatusResults);
                else    
                    realStatusLabel.Text = "Results: " + generateDateString() + realStatusResults;
            }
            catch (Exception exception)
            {
                statusLabel.Text = generateDateString() + "Exception occurred: " + (exception);
                realStatusLabel.Text = generateDateString() + "Exception occurred: " + (exception);
            }
        }

        private void getAllMessagesButton_Click(object sender, EventArgs e)
        {
            try
            {
                label7.Text = "Sending...";
                Form.ActiveForm.Refresh();

                MagfaWebReference.CustomerReturnIncomingFormat[] returnValues = (new GetAllMessagesSample()).getAllMessages(useProxy, proxyAddress, proxyUsername, proxyPassword, username, password,domain, 2);
                if (returnValues.Length == 0)
                    label7.Text = "Results: " + generateDateString() + "No new incoming messages were found...";
                else if (returnValues.Length == 1)
                    label7.Text = "Results: " + generateDateString() + "#1\n" + returnValues[0].ToString();
                else
                    label7.Text = "Results: " + generateDateString() + "#1\n" + returnValues[0].ToString() + "\n#2\n" + returnValues[1].ToString();
            }
            catch (Exception exception)
            {
                label7.Text = generateDateString() + "Exception occurred: " + (exception);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                label9.Text = "Sending...";
                Form.ActiveForm.Refresh();

                MagfaWebReference.CustomerReturnIncomingFormat[] returnValues = (new GetAllMessagesWithNumberSample()).getAllMessagesWithNumber(useProxy, proxyAddress, proxyUsername, proxyPassword, username, password, domain, 2, textBox2.Text);
                if(returnValues.Length == 0)
                    label9.Text = "Results: " + generateDateString() + "No new incoming messages were found...";
                else if(returnValues.Length == 1)
                    label9.Text = "Results: " + generateDateString() + "#1\n" + returnValues[0].ToString();                
                else
                    label9.Text = "Results: " + generateDateString() + "#1\n" + returnValues[0].ToString() + "\n#2\n" + returnValues[1].ToString();
            }
            catch (Exception exception)
            {
                label9.Text = generateDateString() + "Exception occurred: " + (exception);
            }
        }
    }
}
