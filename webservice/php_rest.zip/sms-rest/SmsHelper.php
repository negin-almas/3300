<?php
require_once('Curl.php');
class SmsHelper
{
    const LINE = 'LINENUMBER';
    const USERNAME = 'USERNAME';
    const PASSWORD = 'PASSWORD';
    const API_URL = 'http://sms.3300.ir/services/wsSend.ashx';

    public static function send($numbers, $messages)
    {

        $params = array(
            'username=' . self::USERNAME,
            'password=' . urlencode(self::PASSWORD),
           'line=' . self::LINE,
            'mobile=' . $numbers,
            'message=' . urlencode($messages),
            'life_time=60',
        );
        $result = Curl::send('GET', 'http://sms.3300.ir/services/wsSend.ashx', implode('&', $params));
        var_dump($result);
        if (!($result['responseCode'] == 200 && $result['body']['status'] < 0)) {
            return false;

        } else {
            return true;
        }
    }
}


