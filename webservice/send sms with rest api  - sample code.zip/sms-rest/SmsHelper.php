<?php
/**
 * راهنمای ارسال پیامک با rest api پنل پیامک نگین
 * برای مشاهده فایل راهنما به سایت http://3300.ir/#webservice مراجعه کنید
 */
require_once('Curl.php');
class SmsHelper
{
    const LINE = 'LINENUMBER';
    const USERNAME = 'USERNAME';
    const PASSWORD = 'PASSWORD';
    const API_URL = 'http://sms.3300.ir/api/wsSend.ashx';

    public static function send($numbers, $messages)
    {

        $params = array(
            'username=' . self::USERNAME,
            'password=' . urlencode(self::PASSWORD),
            'line=' . self::LINE,
            'mobile=' . $numbers,
            'message=' . urlencode($messages),
            'life_time=60',
        );
        $result = Curl::send('GET', 'http://sms.3300.ir/api/wsSend.ashx', implode('&', $params));
        var_dump($result);
        if (!($result['responseCode'] == 200 && $result['body']['status'] < 0)) {
            return false;

        } else {
            return true;
        }
    }
}


