using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace test
{
    public class Handler1 : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {

            
            string smsLine = context.Request.Form["to"];
            string smsMobile = context.Request.Form["from"];
            string smsText = context.Request.Form["text"];
            string IP = HttpContext.Current.Request.UserHostAddress;

            context.Response.ContentType = "text/plain";
            context.Response.Write("Time:" +System.DateTime.Now.ToString("HH:mm:ss")+ Environment.NewLine);
            context.Response.Write("IP:"+IP + Environment.NewLine);
            context.Response.Write("Line:" + smsLine + Environment.NewLine);
            context.Response.Write("Mobile:" + smsMobile + Environment.NewLine);
            context.Response.Write("Text:" + smsText + Environment.NewLine);
   
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
