﻿<?php
$smsLine = $_POST['to']; //دريافت شماره خط
$smsMobile = $_POST['from']; //دريافت شماره موبايل
$smsText = $_POST['text']; //دريافت متن پيام
$IP=$_SERVER[REMOTE_ADDR];

echo "Time:";
echo date("H:i:s");//نمايش ساعت
echo "\r\n";
echo "ip:".$IP."\r\n";//نمايش آي پي
echo "Line:".$smsLine."\r\n";
echo "Mobile:".$smsMobile."\r\n";
echo "Text:".$smsText."\r\n";

?>

    